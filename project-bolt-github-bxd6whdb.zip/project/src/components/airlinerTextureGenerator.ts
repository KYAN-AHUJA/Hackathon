import * as THREE from 'three';

/**
 * Procedural texture generator for Airbus A320-style livery:
 * - White fuselage with blue accent stripe
 * - Blue/white vertical stabilizer
 * - Grey wings with registration marks
 * - White engine nacelles with blue stripe
 */

export function createAirlinerBodyTexture(): THREE.CanvasTexture {
  const canvas = document.createElement('canvas');
  canvas.width = 2048;
  canvas.height = 1024;
  const ctx = canvas.getContext('2d');
  if (!ctx) return new THREE.CanvasTexture(canvas);

  ctx.fillStyle = '#f5f7fa';
  ctx.fillRect(0, 0, canvas.width, canvas.height);

  ctx.strokeStyle = '#e2e5eb';
  ctx.lineWidth = 1.5;
  for (let x = 120; x < canvas.width; x += 110) {
    ctx.beginPath();
    ctx.moveTo(x, 0);
    ctx.lineTo(x, canvas.height);
    ctx.stroke();
  }

  [260, 760].forEach((midY) => {
    // Blue accent stripe along fuselage
    ctx.save();
    ctx.fillStyle = '#0825c6';
    ctx.beginPath();
    ctx.moveTo(350, midY + 18);
    ctx.bezierCurveTo(600, midY + 18, 900, midY - 50, 1200, midY - 15);
    ctx.bezierCurveTo(1500, midY + 25, 1750, midY - 80, 2048, midY - 120);
    ctx.lineTo(2048, midY - 50);
    ctx.bezierCurveTo(1700, midY + 5, 1300, midY + 70, 1000, midY + 25);
    ctx.bezierCurveTo(700, midY - 15, 500, midY + 40, 350, midY + 38);
    ctx.closePath();
    ctx.fill();

    // Thin secondary line
    ctx.strokeStyle = '#1a4ed8';
    ctx.lineWidth = 4;
    ctx.beginPath();
    ctx.moveTo(320, midY + 28);
    ctx.bezierCurveTo(550, midY + 28, 750, midY - 30, 1000, midY + 2);
    ctx.stroke();
    ctx.restore();

    // "IMPERIUM" wordmark on fuselage
    ctx.save();
    ctx.translate(1380, midY - 35);
    ctx.font = 'bold 52px "Arial", sans-serif';
    ctx.fillStyle = '#0825c6';
    ctx.strokeStyle = '#ffffff';
    ctx.lineWidth = 6;
    ctx.strokeText('IMPERIUM', 0, 0);
    ctx.fillText('IMPERIUM', 0, 0);
    ctx.restore();

    // Registration mark
    ctx.save();
    ctx.fillStyle = '#374151';
    ctx.font = 'bold 22px monospace';
    ctx.fillText('D-AIMA', 720, midY + 70);
    ctx.restore();

    // Cockpit windshield
    ctx.save();
    ctx.fillStyle = '#0f172a';
    ctx.strokeStyle = '#94a3b8';
    ctx.lineWidth = 3;
    const cpX = 220;
    const cpY = midY - 70;
    for (let p = 0; p < 4; p++) {
      ctx.beginPath();
      ctx.moveTo(cpX + p * 32, cpY);
      ctx.lineTo(cpX + (p + 1) * 32 - 4, cpY + (p === 0 ? 6 : 0));
      ctx.lineTo(cpX + (p + 1) * 32 - 8, cpY + 32);
      ctx.lineTo(cpX + p * 32, cpY + 28);
      ctx.closePath();
      ctx.fill();
      ctx.stroke();
    }
    ctx.restore();

    // Cabin windows strip
    ctx.save();
    const winStart = 380;
    const winEnd = 1650;
    const winStep = 30;
    ctx.fillStyle = '#1e293b';
    ctx.strokeStyle = '#cbd5e1';
    ctx.lineWidth = 1.5;
    for (let wx = winStart; wx < winEnd; wx += winStep) {
      if (Math.abs(wx - 900) < 25) {
        ctx.strokeStyle = '#0825c6';
        ctx.lineWidth = 2.5;
        ctx.strokeRect(wx - 10, midY - 55, 24, 75);
        ctx.strokeStyle = '#cbd5e1';
        ctx.lineWidth = 1.5;
        continue;
      }
      ctx.beginPath();
      ctx.roundRect(wx, midY - 32, 12, 20, 5);
      ctx.fill();
      ctx.stroke();
      ctx.fillStyle = 'rgba(255, 255, 255, 0.45)';
      ctx.fillRect(wx + 2, midY - 30, 3, 16);
      ctx.fillStyle = '#1e293b';
    }
    ctx.restore();
  });

  const texture = new THREE.CanvasTexture(canvas);
  texture.wrapS = THREE.RepeatWrapping;
  texture.wrapT = THREE.ClampToEdgeWrapping;
  texture.needsUpdate = true;
  return texture;
}

export function createAirlinerTailTexture(): THREE.CanvasTexture {
  const canvas = document.createElement('canvas');
  canvas.width = 1024;
  canvas.height = 1024;
  const ctx = canvas.getContext('2d');
  if (!ctx) return new THREE.CanvasTexture(canvas);

  // Blue stabilizer base
  ctx.fillStyle = '#0825c6';
  ctx.fillRect(0, 0, canvas.width, canvas.height);

  // White swoosh patterns
  ctx.fillStyle = '#ffffff';
  ctx.beginPath();
  ctx.moveTo(100, 850);
  ctx.bezierCurveTo(300, 800, 450, 420, 320, 200);
  ctx.bezierCurveTo(450, 280, 520, 540, 350, 880);
  ctx.closePath();
  ctx.fill();

  ctx.beginPath();
  ctx.moveTo(500, 950);
  ctx.bezierCurveTo(620, 870, 750, 500, 600, 250);
  ctx.bezierCurveTo(750, 360, 860, 660, 700, 980);
  ctx.closePath();
  ctx.fill();

  // "IMPERIUM" on tail
  ctx.save();
  ctx.translate(460, 560);
  ctx.rotate(-Math.PI / 4.5);
  ctx.font = 'bold 72px "Arial", sans-serif';
  ctx.fillStyle = '#ffffff';
  ctx.fillText('IMPERIUM', 0, 0);
  ctx.restore();

  // Rudder trim
  ctx.strokeStyle = '#1e40af';
  ctx.lineWidth = 4;
  ctx.beginPath();
  ctx.moveTo(850, 0);
  ctx.lineTo(850, canvas.height);
  ctx.stroke();

  const texture = new THREE.CanvasTexture(canvas);
  texture.needsUpdate = true;
  return texture;
}

export function createAirlinerWingTexture(isLeft: boolean): THREE.CanvasTexture {
  const canvas = document.createElement('canvas');
  canvas.width = 1024;
  canvas.height = 1024;
  const ctx = canvas.getContext('2d');
  if (!ctx) return new THREE.CanvasTexture(canvas);

  // Light grey wing skin
  ctx.fillStyle = '#d8dbe0';
  ctx.fillRect(0, 0, canvas.width, canvas.height);

  // Control surface panels
  ctx.fillStyle = '#c7cbd2';
  ctx.fillRect(200, 650, 750, 260);

  ctx.strokeStyle = '#94a3b8';
  ctx.lineWidth = 2.5;
  for (let x = 200; x < 950; x += 150) {
    ctx.beginPath();
    ctx.moveTo(x, 650);
    ctx.lineTo(x, 910);
    ctx.stroke();
  }

  // Maintenance walkway
  ctx.strokeStyle = '#0f172a';
  ctx.lineWidth = 4;
  ctx.setLineDash([12, 12]);
  ctx.beginPath();
  ctx.moveTo(150, 220);
  ctx.lineTo(820, 220);
  ctx.lineTo(820, 620);
  ctx.lineTo(150, 620);
  ctx.closePath();
  ctx.stroke();
  ctx.setLineDash([]);

  // Registration mark
  ctx.save();
  ctx.translate(520, 420);
  ctx.rotate(isLeft ? -0.22 : 0.22);
  ctx.font = '900 100px "Arial", sans-serif';
  ctx.fillStyle = '#0a0d14';
  ctx.textAlign = 'center';
  ctx.textBaseline = 'middle';
  ctx.fillText('D-AIMA', 0, 0);
  ctx.restore();

  // Blue sharklet tips
  ctx.fillStyle = '#0825c6';
  ctx.beginPath();
  ctx.moveTo(880, 80);
  ctx.lineTo(1024, 80);
  ctx.lineTo(960, 240);
  ctx.lineTo(880, 240);
  ctx.closePath();
  ctx.fill();

  ctx.beginPath();
  ctx.moveTo(880, 280);
  ctx.lineTo(960, 280);
  ctx.lineTo(900, 420);
  ctx.lineTo(840, 420);
  ctx.closePath();
  ctx.fill();

  const texture = new THREE.CanvasTexture(canvas);
  texture.needsUpdate = true;
  return texture;
}

export function createAirlinerTurbofanTexture(): THREE.CanvasTexture {
  const canvas = document.createElement('canvas');
  canvas.width = 512;
  canvas.height = 512;
  const ctx = canvas.getContext('2d');
  if (!ctx) return new THREE.CanvasTexture(canvas);

  ctx.fillStyle = '#f8fafc';
  ctx.fillRect(0, 0, canvas.width, canvas.height);

  // Blue livery stripe
  ctx.fillStyle = '#0825c6';
  ctx.fillRect(0, 200, canvas.width, 38);

  // Chrome intake rim & exhaust ring
  ctx.fillStyle = '#cbd5e1';
  ctx.fillRect(0, 0, 50, canvas.height);
  ctx.fillStyle = '#475569';
  ctx.fillRect(canvas.width - 70, 0, 70, canvas.height);

  const texture = new THREE.CanvasTexture(canvas);
  texture.needsUpdate = true;
  return texture;
}
