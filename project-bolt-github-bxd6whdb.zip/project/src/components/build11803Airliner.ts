import * as THREE from 'three';
import {
  createAirlinerBodyTexture,
  createAirlinerTailTexture,
  createAirlinerWingTexture,
  createAirlinerTurbofanTexture,
} from './airlinerTextureGenerator';

export interface AirlinerModelResult {
  root: THREE.Group;
  landingGearGroup: THREE.Group;
  beaconLights: {
    top: THREE.PointLight;
    bottom: THREE.PointLight;
    strobes: THREE.PointLight[];
  };
  turbofanSpins: THREE.Mesh[];
  exhaustPositions: THREE.Vector3[];
}

/**
 * Builds a procedural Airbus A320-style airliner model.
 * Scaled to scene units: ~6.0 length, ~5.8 wingspan, ~1.9 height.
 * A320 proportions: narrowbody, 25° wing sweep, CFM56 underwing engines,
 * sharklet winglets, tricycle landing gear.
 */
export function build11803Airliner(): AirlinerModelResult {
  const root = new THREE.Group();

  const bodyTexture = createAirlinerBodyTexture();
  const tailTexture = createAirlinerTailTexture();
  const wingTextureL = createAirlinerWingTexture(true);
  const wingTextureR = createAirlinerWingTexture(false);
  createAirlinerTurbofanTexture(); // generated for texture availability

  const whiteMat = new THREE.MeshStandardMaterial({
    color: 0xffffff,
    metalness: 0.08,
    roughness: 0.18,
  });

  const fuselageMat = whiteMat;
  const tailMat = whiteMat;
  const wingMatL = whiteMat;
  const wingMatR = whiteMat;
  const engineMat = whiteMat;

  const chromeMat = new THREE.MeshStandardMaterial({
    color: 0xe6e9ef,
    metalness: 0.92,
    roughness: 0.12,
  });

  const titaniumMat = new THREE.MeshStandardMaterial({
    color: 0x3d414a,
    metalness: 0.85,
    roughness: 0.3,
  });

  const rubberMat = new THREE.MeshStandardMaterial({
    color: 0x16181d,
    roughness: 0.85,
    metalness: 0.08,
  });

  const cockpitGlassMat = new THREE.MeshPhysicalMaterial({
    color: 0x050c1e,
    metalness: 0.45,
    roughness: 0.04,
    transmission: 0.6,
    transparent: true,
    opacity: 0.9,
    reflectivity: 0.95,
  });

  const fanBladeMat = new THREE.MeshStandardMaterial({
    color: 0x22262e,
    metalness: 0.7,
    roughness: 0.3,
  });

  const glowExhaustMat = new THREE.MeshBasicMaterial({
    color: 0x3377ff,
  });

  // ---------------------------------------------------------------------------
  // 1. FUSELAGE — A320 narrowbody proportions
  // Length: 6.0, Radius: 0.40 (narrower than widebody)
  // ---------------------------------------------------------------------------
  const fuselageGeom = new THREE.CylinderGeometry(0.40, 0.40, 5.8, 40, 32);
  fuselageGeom.rotateX(Math.PI / 2);

  const pos = fuselageGeom.attributes.position;
  const uv = fuselageGeom.attributes.uv;

  for (let i = 0; i < pos.count; i++) {
    const z = pos.getZ(i);
    let rScale = 1;
    let yShift = 0;

    // Nose radome
    if (z < -1.3) {
      const t = (-1.3 - z) / (2.9 - 1.3);
      rScale = Math.cos(Math.min(t, 1) * Math.PI * 0.5);
      yShift = -0.05 * Math.sin(t * Math.PI * 0.5);
    }
    // Tail cone — A320 has distinctive upswept tail
    else if (z > 1.2) {
      const t = (z - 1.2) / (2.9 - 1.2);
      rScale = 1 - t * 0.78;
      yShift = 0.14 * Math.sin(t * Math.PI * 0.5);
    }

    pos.setX(i, pos.getX(i) * rScale);
    pos.setY(i, pos.getY(i) * rScale + yShift);

    const u = (z + 2.9) / 5.8;
    uv.setX(i, u);
  }
  fuselageGeom.computeVertexNormals();
  const fuselageMesh = new THREE.Mesh(fuselageGeom, fuselageMat);
  root.add(fuselageMesh);

  // Belly fairing
  const bellyGeom = new THREE.BoxGeometry(0.95, 0.24, 2.5);
  bellyGeom.translate(0, -0.30, 0.1);
  root.add(new THREE.Mesh(bellyGeom, fuselageMat));

  // Pitot tube
  const pitot = new THREE.Mesh(new THREE.CylinderGeometry(0.01, 0.005, 0.28, 8), chromeMat);
  pitot.rotateX(Math.PI / 2);
  pitot.position.set(0, -0.05, -3.0);
  root.add(pitot);

  // ---------------------------------------------------------------------------
  // 2. COCKPIT WINDSHIELD
  // ---------------------------------------------------------------------------
  const cockpitGeom = new THREE.SphereGeometry(0.408, 24, 16, 0, Math.PI, 0, Math.PI * 0.36);
  cockpitGeom.rotateX(Math.PI * 0.49);
  cockpitGeom.scale(0.88, 0.52, 1.15);
  const cockpitMesh = new THREE.Mesh(cockpitGeom, cockpitGlassMat);
  cockpitMesh.position.set(0, 0.14, -1.78);
  root.add(cockpitMesh);

  const centerFrame = new THREE.Mesh(new THREE.BoxGeometry(0.022, 0.10, 0.36), chromeMat);
  centerFrame.rotateX(0.32);
  centerFrame.position.set(0, 0.23, -1.86);
  root.add(centerFrame);

  // ---------------------------------------------------------------------------
  // 3. SWEPT WINGS WITH SHARKLETS — A320 25° sweep, ~5.8 span
  // ---------------------------------------------------------------------------
  const wingGroup = new THREE.Group();
  wingGroup.position.set(0, -0.20, 0);

  const buildWingHalf = (isLeft: boolean) => {
    const side = isLeft ? -1 : 1;
    const wingHalf = new THREE.Group();

    const shape = new THREE.Shape();
    shape.moveTo(0.42 * side, -0.42);
    shape.lineTo(2.9 * side, 1.35);   // 25° sweep
    shape.lineTo(2.82 * side, 1.68);
    shape.lineTo(0.42 * side, 0.88);
    shape.closePath();

    const geom = new THREE.ExtrudeGeometry(shape, {
      depth: 0.075,
      bevelEnabled: true,
      bevelSegments: 2,
      bevelSize: 0.02,
      bevelThickness: 0.02,
    });
    geom.rotateX(Math.PI / 2);

    const wMesh = new THREE.Mesh(geom, isLeft ? wingMatL : wingMatR);
    wMesh.rotation.z = -side * 0.03;
    wingHalf.add(wMesh);

    // Leading edge slat
    const slat = new THREE.Mesh(new THREE.CylinderGeometry(0.02, 0.02, 2.9, 8), chromeMat);
    slat.position.set(1.6 * side, 0.02, 0.46);
    slat.rotation.z = side * (Math.PI / 2 - 0.46);
    wingHalf.add(slat);

    // Flap track fairings
    [1.0, 1.7, 2.4].forEach((cx, idx) => {
      const canoeGeom = new THREE.ConeGeometry(0.04, 0.42, 8);
      canoeGeom.rotateX(Math.PI / 2);
      const canoe = new THREE.Mesh(canoeGeom, fuselageMat);
      canoe.position.set(cx * side, -0.05, 0.5 + idx * 0.32);
      wingHalf.add(canoe);
    });

    // Sharklet (A320 blended winglet)
    const wingletGeom = new THREE.ConeGeometry(0.07, 0.62, 4);
    wingletGeom.scale(0.22, 1, 1.3);
    const winglet = new THREE.Mesh(wingletGeom, tailMat);
    winglet.position.set(2.92 * side, 0.25, 1.52);
    winglet.rotation.z = side * 0.52;
    winglet.rotation.y = -side * 0.10;
    wingHalf.add(winglet);

    // Nav light
    const navLight = new THREE.PointLight(isLeft ? 0xff2020 : 0x20ff50, 1.2, 3.5);
    navLight.position.set(2.96 * side, 0.30, 1.54);
    wingHalf.add(navLight);

    // Strobe
    const strobe = new THREE.PointLight(0xffffff, 1.5, 4);
    strobe.position.set(2.94 * side, 0.30, 1.59);
    wingHalf.add(strobe);

    return { wingHalf, strobe };
  };

  const leftWingData = buildWingHalf(true);
  const rightWingData = buildWingHalf(false);
  wingGroup.add(leftWingData.wingHalf);
  wingGroup.add(rightWingData.wingHalf);
  root.add(wingGroup);

  // ---------------------------------------------------------------------------
  // 4. CFM56-5B TURBOFAN ENGINES — under-wing, A320 style
  // ---------------------------------------------------------------------------
  const engineGroup = new THREE.Group();
  const turbofanSpins: THREE.Mesh[] = [];
  const exhaustPositions: THREE.Vector3[] = [];

  for (let side = -1; side <= 1; side += 2) {
    const engX = side * 1.20;  // closer to fuselage (narrowbody)
    const engY = -0.28;
    const engZ = 0.30;

    // Pylon
    const pylonGeom = new THREE.BoxGeometry(0.11, 0.32, 1.1);
    pylonGeom.translate(0, 0.14, -0.12);
    const pylon = new THREE.Mesh(pylonGeom, titaniumMat);
    pylon.position.set(engX, engY + 0.12, engZ);
    pylon.rotateX(0.04);
    engineGroup.add(pylon);

    // Nacelle — A320 CFM56 is relatively long and slim
    const nacelleGeom = new THREE.CylinderGeometry(0.27, 0.25, 1.45, 32);
    nacelleGeom.rotateX(Math.PI / 2);
    const nacelle = new THREE.Mesh(nacelleGeom, engineMat);
    nacelle.position.set(engX, engY, engZ);
    engineGroup.add(nacelle);

    // Intake lip
    const intakeLip = new THREE.Mesh(new THREE.TorusGeometry(0.26, 0.028, 10, 32), chromeMat);
    intakeLip.position.set(engX, engY, engZ - 0.73);
    engineGroup.add(intakeLip);

    // Fan disk
    const fanDisk = new THREE.Mesh(new THREE.CircleGeometry(0.24, 24), fanBladeMat);
    fanDisk.position.set(engX, engY, engZ - 0.68);
    turbofanSpins.push(fanDisk);
    engineGroup.add(fanDisk);

    // Spinner cone
    const spinnerGeom = new THREE.ConeGeometry(0.07, 0.24, 16);
    spinnerGeom.rotateX(-Math.PI / 2);
    const spinner = new THREE.Mesh(spinnerGeom, titaniumMat);
    spinner.position.set(engX, engY, engZ - 0.70);
    engineGroup.add(spinner);

    // Exhaust nozzle
    const exhaustNozzle = new THREE.Mesh(
      new THREE.CylinderGeometry(0.20, 0.16, 0.30, 24),
      titaniumMat
    );
    exhaustNozzle.rotateX(Math.PI / 2);
    exhaustNozzle.position.set(engX, engY, engZ + 0.86);
    engineGroup.add(exhaustNozzle);

    const exhaustPlug = new THREE.Mesh(new THREE.ConeGeometry(0.08, 0.30, 16), titaniumMat);
    exhaustPlug.rotateX(Math.PI / 2);
    exhaustPlug.position.set(engX, engY, engZ + 1.08);
    engineGroup.add(exhaustPlug);

    const thrustGlow = new THREE.Mesh(new THREE.CircleGeometry(0.14, 16), glowExhaustMat);
    thrustGlow.position.set(engX, engY, engZ + 1.02);
    engineGroup.add(thrustGlow);

    exhaustPositions.push(new THREE.Vector3(engX, engY, engZ + 1.04));
  }
  root.add(engineGroup);

  // ---------------------------------------------------------------------------
  // 5. EMPENNAGE — A320 vertical & horizontal stabilizers
  // ---------------------------------------------------------------------------
  const empennageGroup = new THREE.Group();

  // Vertical stabilizer — A320 tall fin
  const finShape = new THREE.Shape();
  finShape.moveTo(0, 0);
  finShape.lineTo(0.32, 1.65);
  finShape.lineTo(0.85, 1.65);
  finShape.lineTo(1.50, 0);
  finShape.closePath();

  const finGeom = new THREE.ExtrudeGeometry(finShape, {
    depth: 0.06,
    bevelEnabled: true,
    bevelSize: 0.015,
    bevelThickness: 0.015,
  });
  finGeom.rotateY(Math.PI / 2);
  finGeom.translate(0, 0.36, 1.15);

  empennageGroup.add(new THREE.Mesh(finGeom, tailMat));

  // Horizontal stabilizer
  const hStabShape = new THREE.Shape();
  hStabShape.moveTo(0, 0);
  hStabShape.lineTo(1.45, 0.62);
  hStabShape.lineTo(1.36, 0.95);
  hStabShape.lineTo(0, 0.40);
  hStabShape.lineTo(-1.36, 0.95);
  hStabShape.lineTo(-1.45, 0.62);
  hStabShape.closePath();

  const hStabGeom = new THREE.ExtrudeGeometry(hStabShape, {
    depth: 0.038,
    bevelEnabled: true,
    bevelSize: 0.01,
    bevelThickness: 0.01,
  });
  hStabGeom.rotateX(Math.PI / 2);
  hStabGeom.translate(0, 0.26, 2.25);

  empennageGroup.add(new THREE.Mesh(hStabGeom, fuselageMat));

  // APU exhaust
  const apu = new THREE.Mesh(new THREE.CylinderGeometry(0.035, 0.035, 0.10, 12), titaniumMat);
  apu.rotateX(Math.PI / 2);
  apu.position.set(0, 0.10, 2.92);
  empennageGroup.add(apu);

  // Tail nav light
  const tailNavLight = new THREE.PointLight(0xffffff, 1.4, 4);
  tailNavLight.position.set(0, 0.10, 2.96);
  empennageGroup.add(tailNavLight);

  root.add(empennageGroup);

  // ---------------------------------------------------------------------------
  // 6. TRICYCLE LANDING GEAR — A320 style
  // ---------------------------------------------------------------------------
  const landingGearGroup = new THREE.Group();

  // Nose gear
  const noseStrut = new THREE.Mesh(new THREE.CylinderGeometry(0.032, 0.030, 0.68, 12), chromeMat);
  noseStrut.position.set(0, -0.46, -1.55);
  landingGearGroup.add(noseStrut);

  const noseTorqueLink = new THREE.Mesh(new THREE.BoxGeometry(0.035, 0.16, 0.055), titaniumMat);
  noseTorqueLink.position.set(0, -0.54, -1.50);
  noseTorqueLink.rotateX(0.3);
  landingGearGroup.add(noseTorqueLink);

  const taxiLight = new THREE.PointLight(0xfff4d6, 1.8, 6);
  taxiLight.position.set(0, -0.42, -1.61);
  landingGearGroup.add(taxiLight);

  const taxiFixture = new THREE.Mesh(new THREE.CylinderGeometry(0.028, 0.028, 0.035, 12), chromeMat);
  taxiFixture.rotateX(Math.PI / 2);
  taxiFixture.position.set(0, -0.42, -1.59);
  landingGearGroup.add(taxiFixture);

  for (let side = -1; side <= 1; side += 2) {
    const tire = new THREE.Mesh(new THREE.CylinderGeometry(0.11, 0.11, 0.065, 18), rubberMat);
    tire.rotateZ(Math.PI / 2);
    tire.position.set(side * 0.075, -0.78, -1.55);
    landingGearGroup.add(tire);

    const hub = new THREE.Mesh(new THREE.CylinderGeometry(0.055, 0.055, 0.07, 12), chromeMat);
    hub.rotateZ(Math.PI / 2);
    hub.position.set(side * 0.075, -0.78, -1.55);
    landingGearGroup.add(hub);
  }

  // Main gear
  for (let side = -1; side <= 1; side += 2) {
    const mainStrut = new THREE.Mesh(new THREE.CylinderGeometry(0.042, 0.038, 0.78, 12), chromeMat);
    mainStrut.position.set(side * 0.88, -0.48, 0.40);
    landingGearGroup.add(mainStrut);

    const mainAxle = new THREE.Mesh(new THREE.CylinderGeometry(0.022, 0.022, 0.26, 8), chromeMat);
    mainAxle.rotateZ(Math.PI / 2);
    mainAxle.position.set(side * 0.88, -0.82, 0.40);
    landingGearGroup.add(mainAxle);

    for (let w = -1; w <= 1; w += 2) {
      const tire = new THREE.Mesh(new THREE.CylinderGeometry(0.155, 0.155, 0.085, 20), rubberMat);
      tire.rotateZ(Math.PI / 2);
      tire.position.set(side * 0.88 + w * 0.08, -0.82, 0.40);
      landingGearGroup.add(tire);

      const hub = new THREE.Mesh(new THREE.CylinderGeometry(0.072, 0.072, 0.09, 12), chromeMat);
      hub.rotateZ(Math.PI / 2);
      hub.position.set(side * 0.88 + w * 0.08, -0.82, 0.40);
      landingGearGroup.add(hub);
    }
  }
  root.add(landingGearGroup);

  // ---------------------------------------------------------------------------
  // 7. ANTI-COLLISION BEACONS
  // ---------------------------------------------------------------------------
  const topBeaconLight = new THREE.PointLight(0xff1818, 1.8, 5);
  topBeaconLight.position.set(0, 0.48, 0.1);
  root.add(topBeaconLight);

  const topBeaconLens = new THREE.Mesh(
    new THREE.SphereGeometry(0.03, 8, 8),
    new THREE.MeshBasicMaterial({ color: 0xff1111 })
  );
  topBeaconLens.position.set(0, 0.44, 0.1);
  root.add(topBeaconLens);

  const bottomBeaconLight = new THREE.PointLight(0xff1818, 1.8, 5);
  bottomBeaconLight.position.set(0, -0.46, 0.3);
  root.add(bottomBeaconLight);

  const bottomBeaconLens = new THREE.Mesh(
    new THREE.SphereGeometry(0.03, 8, 8),
    new THREE.MeshBasicMaterial({ color: 0xff1111 })
  );
  bottomBeaconLens.position.set(0, -0.42, 0.3);
  root.add(bottomBeaconLens);

  return {
    root,
    landingGearGroup,
    beaconLights: {
      top: topBeaconLight,
      bottom: bottomBeaconLight,
      strobes: [leftWingData.strobe, rightWingData.strobe, tailNavLight],
    },
    turbofanSpins,
    exhaustPositions,
  };
}
